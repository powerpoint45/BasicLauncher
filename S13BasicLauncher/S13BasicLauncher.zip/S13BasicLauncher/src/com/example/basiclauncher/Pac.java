package com.example.basiclauncher;

import android.graphics.drawable.Drawable;

public class Pac {
	Drawable icon;
	String name;
	String packageName;
	String label;
}
